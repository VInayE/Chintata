/*global store*/
/*global moment*/

var userSystemsId;
var cache = [];
var filterDelete = " ";

function btnLike(button){
  var inputs = {};
  var outputs = {};
  var className = button.getAttribute("class");
  debugger;
  
  if(className=="btn btn-default pull-right standard-orange-icons") {
    button.className = "btn btn-default pull-right standard-dark-icons black";
    inputs.FKIssue = button.name;
    
    fsi.workflow('DeleteMeToo', inputs, outputs, null, 
                 function(responseData){button.textContent = responseData.Count + ' MeToo!';
                                        var inputs1 = {};
                                        var outputs1 = {};
                                        inputs1.Action = "MeToo";
                                        inputs1.UserId = fsi.getLoggedUserId();
                                        inputs1.Flag = "Sub";
                                        
                                        fsi.workflow('AddSubPoints', inputs1, outputs1, null, 
                                                     function(responseData){
                                                       debugger;
                                                       
                                                     },
                                                     function(errorData){
                                                      // alert("Error1: "+errorData);
                                                     }); 
                                        
                                       },
                 function(errorData){});
  }
  else{
    button.className = "btn btn-default pull-right standard-orange-icons";
    inputs.FKIssue = button.name;
    
    fsi.workflow('CreateMeToo', inputs, outputs, null, 
                 function(responseData){
                   debugger;
                   button.textContent = responseData.Count + ' MeToo!';
                   var inputs1 = {};
                   var outputs1 = {};
                   inputs1.Action = "MeToo";
                   inputs1.UserId = fsi.getLoggedUserId();
                   inputs1.Flag = "Add";
                   
                   fsi.workflow('AddSubPoints', inputs1, outputs1, null, 
                                function(responseData){
                                  debugger;
                                  
                                },
                                function(errorData){
                                 // alert("Error2: "+errorData);
                                }); 
                 },
                 function(errorData){});
  }
  
  
  
}

function onNotificationClick(){
  debugger;
  fsi.changePage('Messages');
}

function getAvatar(userId){
  var cache = store.get('avatars');
  var userImage = ''; 
  
  for (var z=0; z < cache.length; z++){
    if (cache[z].UserID == userId){
      userImage = cache[z].Avtar;
      break; 
    }
  } 
  return userImage;
}

function friendlyDate(dateTofriendify){
  var logdate = dateTofriendify;
  
  var diffLogDate = moment.utc().diff(logdate, 'minutes');
  
  var crntdate = moment.utc();
  var sdate;
  
  if(diffLogDate <= 60)
  {
    sdate = diffLogDate + " " + "minutes ago";
    
  }
  else if(diffLogDate <= 1440)
  {
    var v1 = Math.round(diffLogDate/60);
    sdate =  v1 + " " + "hours ago";
    
  }
  else
  {
    sdate = moment(dateTofriendify).format("MMM DD YYYY HH:mm");
    
  }
  return sdate;
}

function btnLikecomment(button){

  var className = button.getAttribute("class");
 
  debugger;
 
  if(className=="btn btn-default pull-right unlike") {
      var inputs1 = {};
     var outputs1 = {};
     inputs1.FKComment = button.name;
     button.className = "btn btn-default pull-right black like";
    
    
     fsi.workflow('DeleteCommentLike', inputs1, outputs1, null,
                 function(responseData){button.textContent = responseData.Count +  ' Like';
                                     
                                        var inputs2 = {};
                                        var outputs2 = {};
                                        inputs2.Action = "Like";
                                        inputs2.UserId = fsi.getLoggedUserId();
                                        inputs2.Flag = "Sub";
                                        fsi.workflow('AddSubPoints', inputs2, outputs2, null, 
                                                     function(responseData){
                                                       debugger;
                                                       
                                                     },
                                                     function(errorData){
                                                       alert("Error1: "+errorData);
                                                     }); 
                                       },
                 function(errorData){alert("inside delete failed");   });
  }
  else{
    button.className = "btn btn-default pull-right unlike";
     var inputs4 = {};
     var outputs4 = {};
     inputs4.FKComment = button.name;
    fsi.workflow('CreateCommentLike', inputs4, outputs4, null, 
                 function(responseData){
                   debugger;
                   button.textContent = responseData.Count + ' Like';
                   var inputs3 = {};
                   var outputs3 = {};
                   inputs3.Action = "Like";
                   inputs3.UserId = fsi.getLoggedUserId();
                   inputs3.Flag = "Add";
                   
                   fsi.workflow('AddSubPoints', inputs3, outputs3, null, 
                                function(responseData){
                                  debugger;
                                  
                                },
                                function(errorData){
                                  alert("Error2: "+errorData);
                                }); 
                 },
                 function(errorData){});
  }
  
  
  
}
function removePageTitles(){
  $('[id=mast-header] .page-title').remove();
  $('[id=mast-header] .page-title-urankings').remove();
  $('[id=mast-header] .page-title-leaderboard').remove();
  $('[id=mast-header] .page-title-logit').remove();
  $('[id=mast-header] .page-title-mytimeline').remove();
  $('[id=mast-header] .page-title-leavefeedback').remove();
  $('[id=mast-header] .page-title-edituser-rank').remove();
  $('[id=mast-header] .page-title-addnew').remove();
  $('[id=mast-header] .page-title-comments').remove();
  $('[id=mast-header] .page-title-share').remove();
  $('[id=mast-header] .page-title-profile').remove();
  $('[id=mast-header] .page-title-notifications').remove();
  $('[id=mast-header] .back-button').remove();
}

function searchAvatars(userId){
  var avatars = store.get('Avatars');
  var image = "";
  
  if (avatars !== undefined){
    if(avatars.length>0) {
      //check the userId if is there in cache or not for loop
      for (var z=0; z < avatars.length; z++){
        if (avatars[z].UserID == userId){
          image = avatars[z].Avatar;
          break; 
        }
      }
    }
  }
  return image;
}

function addAvatar(userId, avatar){
  var avatars = store.get('Avatars');
  if (avatars === undefined){avatars = [];}
    
  avatars.push({'UserID':userId,'Avatar':avatar});
  store.set('Avatars',avatars);
}